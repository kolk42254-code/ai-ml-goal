import os
import time


while True:
    os.system("cls")
    op = ["Eye with heart animation", "Eye with heart animation realistic", "Eye blinking","Eye animation with beautiful Terminal", "Quit"]
    for i, j in enumerate(op, start=1):
        print(f"{i}.{j}")
    user = input("Choose the option -> ")
    os.system("cls")
    if user == "5":
        os.system("cls")
        for i in range(3, 0, -1):
            print(f"Terminating in {i}s", end="\r", flush=True)
            time.sleep(1.0)
        exit()
    for i in range(3, 0, -1):
        print(f"Launching in {i}s", end="\r", flush=True)
        time.sleep(1.0)
    try:
        os.system("cls")
        if user=="1":
            os.system(r"python3 C:\Users\Lenovo\ai-ml-goal\Eye_with_heart.py")
        elif user == "2":
            os.system(r"python3 C:\Users\Lenovo\ai-ml-goal\eye_to_space2.py")
        elif user == "3":
            os.system(r"python3 C:\Users\Lenovo\ai-ml-goal\Eye_blink.py")
        elif user == "4":
            os.system(r"python3 C:\Users\Lenovo\ai-ml-goal\eye_to_space3.py")
        else:
            print("Please choose only above options")
    except KeyboardInterrupt:
        os.system("cls")
        for i in range(3, 0, -1):
            print(f"Animation Terminating in {i}s", end="\r", flush=True)
            time.sleep(1.0)